import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-homefriend',
  templateUrl: './homefriend.component.html',
  styleUrls: ['./homefriend.component.css']
})
export class HomefriendComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
